#ifndef GLOBAL_H
#define GLOBAL_H

#include"Inventory.h"

// search function --> to search specific product using product code from Inventory arr
void search(Inventory arr_[], int size_, int productCode_);

#endif // GLOBAL_H
