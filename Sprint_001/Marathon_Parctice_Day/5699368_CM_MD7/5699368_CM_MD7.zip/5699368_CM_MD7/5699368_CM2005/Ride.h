#ifndef RIDE_H
#define RIDE_H

enum class Ride{
    REGULAR = 0,
    COMFORT = 1
};

#endif // RIDE_H
