// Severity Level Header file

#ifndef SEVERITYLEVEL_H
#define SEVERITYLEVEL_H

enum class SeverityLevel{
    INFO,
    WARN,
    CRIT
};

#endif