// Severity Level Header file

#ifndef SEVERITYLEVEL_H
#define SEVERITYLEVEL_H

enum class SeverityLevel{
    INFO=0,
    WARN=1,
    CRIT=2
};

#endif