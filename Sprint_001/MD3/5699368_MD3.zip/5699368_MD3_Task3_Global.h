#ifndef GLOBAL_H
#define GLOBAL_H

#include"5699368_MD3_Task3_DTC.h"

// global function to print all DTC --> also ensures that the values of pointers inside array will not change
void displayAllDTCs(DTC* const* array, const int size);

#endif