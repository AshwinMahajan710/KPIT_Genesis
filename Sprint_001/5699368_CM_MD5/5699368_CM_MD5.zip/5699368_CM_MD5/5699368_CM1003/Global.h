#include"VehicleFuelAccount.h"

void applyBonusToFleet(VehicleFuelAccount* arr_[], int size_);
double getTotalFleetFuel(VehicleFuelAccount* arr_[], int size_);