
// Global functions .h file..

#include"Inventory.h"

void Search(Inventory* arr_, int size_, int productCode_);