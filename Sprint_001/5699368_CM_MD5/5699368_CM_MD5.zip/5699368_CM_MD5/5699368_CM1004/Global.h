#include"Vehicle.h"

void findMinAvgScoore(Vehicle vArr_[], int size_);
void showVehicles(Vehicle vArr_[], int size_, VehicleType type_);