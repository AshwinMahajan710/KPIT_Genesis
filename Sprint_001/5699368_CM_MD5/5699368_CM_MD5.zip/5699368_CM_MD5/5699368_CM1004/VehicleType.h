// enum object

#ifndef VEHICLETYPE_H
#define VEHICLETYPE_H

enum class VehicleType {
    COMMERCIAL, 
    PASSENGER
};

#endif // VEHICLETYPE_H
