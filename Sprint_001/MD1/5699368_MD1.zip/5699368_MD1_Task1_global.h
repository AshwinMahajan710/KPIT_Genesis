// Global functions header file

#include"5699368_MD1_Task1_FleetVehicle.h"

void assignDriver(FleetVehicle& vehicle_, std::string name_);
void refuelVehicle(FleetVehicle& vehicle_, float fuelAmmount_);