#ifndef VEHICLESTATE_H
#define VEHICLESTATE_H

enum class VehicleState{
    PARKED,
    INTRANSIT,
    MAINTAINANCE
};

#endif // VEHICLESTATE_H
