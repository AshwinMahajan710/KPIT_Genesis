#ifndef GLOBAL_H
#define GLOBAL_H

#include"Vehicle.h"

void printVehicleInfo(Vehicle* vehicle);

#endif // GLOBAL_H
