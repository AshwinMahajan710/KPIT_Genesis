#ifndef VEHICLETYPE_H
#define VEHICLETYPE_H

enum class VehicleType{
    UNKONWN,
    CAR,
    TRUCK
};

#endif // VEHICLETYPE_H
