#ifndef SEVERITY_H
#define SEVERITY_H

enum class Severity{
    INFO,
    WARNING,
    CRITICAL
};

#endif // SEVERITY_H
