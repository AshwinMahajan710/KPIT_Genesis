#ifndef GLOBAL_H
#define GLOBAL_H

#include<string>
#include"VehicleSummary.h"
#include<vector>
#include"Owner.h"

std::string ownerReport(const Owner& owner);

#endif // GLOBAL_H
