#ifndef GLOBAL_H
#define GLOBAL_H

#include<string>
#include<variant>
#include"5699368_MD14_Task2_SensorReading.h"

// function to print sensorinfo
void printSensorReading(const SensorReading& sensor);

#endif // GLOBAL_H
