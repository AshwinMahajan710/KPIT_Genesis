#ifndef INC_5699368_MD2_TASK1_GLOBAL_H
#define INC_5699368_MD2_TASK1_GLOBAL_H

#include"5699368_MD4_Task1_Vehicle.h"

void logVehicleByValue(Vehicle V);
void logVehicleByRef(Vehicle& V);
void logVehicleByRRef(Vehicle&& V);
void logVehicleByPtr(Vehicle* V);

#endif // INC_5699368_MD2_TASK1_GLOBAL_H
