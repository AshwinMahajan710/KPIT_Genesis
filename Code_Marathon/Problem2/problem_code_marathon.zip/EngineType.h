#ifndef ENGINETYPE_H
#define ENGINETYPE_H

// enum class
enum class EngineType{
    PETROL, 
    DIESEL, 
    HYBRID
};

#endif // ENGINETYPE_H
